// Initialize app
var myApp = new Framework7();


// If we need to use custom DOM library, let's save it to $$ variable:
var $$ = Dom7;

// Add view
var mainView = myApp.addView('.view-main', {
    // Because we want to use dynamic navbar, we need to enable it for this view:
    dynamicNavbar: true
});

// Handle Cordova Device Ready Event
$$(document).on('deviceready', function() {
    console.log("Device is ready!");
});


// Now we need to run the code that will be executed only for About page.

// Option 1. Using page callback for page (for "about" page in this case) (recommended way):

    // Do something here for "about" page



// Option 2. Using one 'pageInit' event handler for all pages:
$$(document).on('pageInit', function (e) {
    
    var page = e.detail.page;

    if (page.name === 'about') {
        
        myApp.alert('Here comes About page');
    }
})
var NumberInput;
var currencyRate;

function readingNumberInput(){

    NumberInput = document.getElementById('NumberInput').value;

}

function getCurrencyRate(){


    var http = new XMLHttpRequest();

    const url = 'http://www.apilayer.net/api/live?access_key=07e1c5cd30fb350590c2f7eb8746162f&currencies=EUR&source=USD&format=1';
    http.open("GET", url);
    http.send();


    http.onreadystatechange = (e) => {
        
        var response = http.responseText;

        var responseJSON = JSON.parse(response); 
    
        console.log(responseJSON);

        currencyRate = responseJSON.quotes.USDEUR;
        
    }
}

function conversion(){

    readingNumberInput();
    getCurrencyRate();
    var currencyResult = NumberInput * currencyRate;
    document.getElementById('currencyResult').innerHTML = "$"+currencyResult;
}


function conversion2(){

    readingNumberInput();
    getCurrencyRate();
    var currencyResult = NumberInput / currencyRate;
    document.getElementById('currencyResult').innerHTML = "€"+currencyResult;

}

    //Weather

    var lat
    var lon;
    
    function getLocation(){
      navigator.geolocation.getCurrentPosition(geoCallback, onError);
  }
  function geoCallback(position){
  console.log(position);
  var lat = position.coords.latitude;
  var lon = position.coords.longitude;
   }

    function openCage(){var lat, lon ,http = new XMLHttpRequest();
       const url = 'http://api.apixu.com/v1/current.json?key=f67dfb1332d64bc8abb114535192404&q=Dublin';
        http.open("GET", url);
        http.send();
        http.onreadystatechange = (e) => {
            var response = http.responseText;
            var responseJSON = JSON.parse(response);
            
            console.log(responseJSON);
            
            var tempC = responseJSON.current.temp_c;
            var tempF = responseJSON.current.temp_f;
            var city= responseJSON.location.name;
            var country= responseJSON.location.country;
            var weather= responseJSON.current.condition.text;
            var icon= responseJSON.current.condition.icon;
            var CurrentWeather="<br>"+city+", " +country+"<br>"+weather+"<br>"+tempC+"°C/ "+tempF+"°F";
            document.getElementById('weather').innerHTML= CurrentWeather;
            
        
        $("#icon").html('<img src="'+icon+'" alt="icon"/>');
        }
    }

    function GetWeather(){

        getLocation();
        openCage();
    }
    function onError(msg){console.log(msg)}
  
        
      
    

